package androidx.asynclayoutinflater;

public final class R {
    public static final class attr {
        public static final int alpha = 0x7F030029;  // attr:alpha
        public static final int font = 0x7F03008D;  // attr:font
        public static final int fontProviderAuthority = 0x7F03008F;  // attr:fontProviderAuthority
        public static final int fontProviderCerts = 0x7F030090;  // attr:fontProviderCerts
        public static final int fontProviderFetchStrategy = 0x7F030091;  // attr:fontProviderFetchStrategy
        public static final int fontProviderFetchTimeout = 0x7F030092;  // attr:fontProviderFetchTimeout
        public static final int fontProviderPackage = 0x7F030093;  // attr:fontProviderPackage
        public static final int fontProviderQuery = 0x7F030094;  // attr:fontProviderQuery
        public static final int fontStyle = 0x7F030096;  // attr:fontStyle
        public static final int fontVariationSettings = 0x7F030097;  // attr:fontVariationSettings
        public static final int fontWeight = 0x7F030098;  // attr:fontWeight
        public static final int ttcIndex = 0x7F03012B;  // attr:ttcIndex

    }

    public static final class color {
        public static final int notification_action_color_filter = 0x7F050056;  // color:notification_action_color_filter
        public static final int notification_icon_bg_color = 0x7F050057;  // color:notification_icon_bg_color
        public static final int ripple_material_light = 0x7F050062;  // color:ripple_material_light
        public static final int secondary_text_default_material_light = 0x7F050064;  // color:secondary_text_default_material_light

    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 0x7F060056;  // dimen:compat_button_inset_horizontal_material
        public static final int compat_button_inset_vertical_material = 0x7F060057;  // dimen:compat_button_inset_vertical_material
        public static final int compat_button_padding_horizontal_material = 0x7F060058;  // dimen:compat_button_padding_horizontal_material
        public static final int compat_button_padding_vertical_material = 0x7F060059;  // dimen:compat_button_padding_vertical_material
        public static final int compat_control_corner_material = 0x7F06005A;  // dimen:compat_control_corner_material
        public static final int compat_notification_large_icon_max_height = 0x7F06005B;  // dimen:compat_notification_large_icon_max_height
        public static final int compat_notification_large_icon_max_width = 0x7F06005C;  // dimen:compat_notification_large_icon_max_width
        public static final int notification_action_icon_size = 0x7F060066;  // dimen:notification_action_icon_size
        public static final int notification_action_text_size = 0x7F060067;  // dimen:notification_action_text_size
        public static final int notification_big_circle_margin = 0x7F060068;  // dimen:notification_big_circle_margin
        public static final int notification_content_margin_start = 0x7F060069;  // dimen:notification_content_margin_start
        public static final int notification_large_icon_height = 0x7F06006A;  // dimen:notification_large_icon_height
        public static final int notification_large_icon_width = 0x7F06006B;  // dimen:notification_large_icon_width
        public static final int notification_main_column_padding_top = 0x7F06006C;  // dimen:notification_main_column_padding_top
        public static final int notification_media_narrow_margin = 0x7F06006D;  // dimen:notification_media_narrow_margin
        public static final int notification_right_icon_size = 0x7F06006E;  // dimen:notification_right_icon_size
        public static final int notification_right_side_padding_top = 0x7F06006F;  // dimen:notification_right_side_padding_top
        public static final int notification_small_icon_background_padding = 0x7F060070;  // dimen:notification_small_icon_background_padding
        public static final int notification_small_icon_size_as_large = 0x7F060071;  // dimen:notification_small_icon_size_as_large
        public static final int notification_subtext_size = 0x7F060072;  // dimen:notification_subtext_size
        public static final int notification_top_pad = 0x7F060073;  // dimen:notification_top_pad
        public static final int notification_top_pad_large_text = 0x7F060074;  // dimen:notification_top_pad_large_text

    }

    public static final class drawable {
        public static final int notification_action_background = 0x7F070072;  // drawable:notification_action_background
        public static final int notification_bg = 0x7F070073;  // drawable:notification_bg
        public static final int notification_bg_low = 0x7F070074;  // drawable:notification_bg_low
        public static final int notification_bg_low_normal = 0x7F070075;  // drawable:notification_bg_low_normal
        public static final int notification_bg_low_pressed = 0x7F070076;  // drawable:notification_bg_low_pressed
        public static final int notification_bg_normal = 0x7F070077;  // drawable:notification_bg_normal
        public static final int notification_bg_normal_pressed = 0x7F070078;  // drawable:notification_bg_normal_pressed
        public static final int notification_icon_background = 0x7F070079;  // drawable:notification_icon_background
        public static final int notification_template_icon_bg = 0x7F07007A;  // drawable:notification_template_icon_bg
        public static final int notification_template_icon_low_bg = 0x7F07007B;  // drawable:notification_template_icon_low_bg
        public static final int notification_tile_bg = 0x7F07007C;  // drawable:notification_tile_bg
        public static final int notify_panel_notification_icon_bg = 0x7F07007D;  // drawable:notify_panel_notification_icon_bg

    }

    public static final class id {
        public static final int action_container = 0x7F08002F;  // id:action_container
        public static final int action_divider = 0x7F080031;  // id:action_divider
        public static final int action_image = 0x7F080032;  // id:action_image
        public static final int action_text = 0x7F080038;  // id:action_text
        public static final int actions = 0x7F080039;  // id:actions
        public static final int async = 0x7F080043;  // id:async
        public static final int blocking = 0x7F080046;  // id:blocking
        public static final int chronometer = 0x7F080056;  // id:chronometer
        public static final int forever = 0x7F08006D;  // id:forever
        public static final int icon = 0x7F080072;  // id:icon
        public static final int icon_group = 0x7F080073;  // id:icon_group
        public static final int info = 0x7F080077;  // id:info
        public static final int italic = 0x7F080078;  // id:italic
        public static final int line1 = 0x7F08007B;  // id:line1
        public static final int line3 = 0x7F08007C;  // id:line3
        public static final int normal = 0x7F080085;  // id:normal
        public static final int notification_background = 0x7F080087;  // id:notification_background
        public static final int notification_main_column = 0x7F080088;  // id:notification_main_column
        public static final int notification_main_column_container = 0x7F080089;  // id:notification_main_column_container
        public static final int right_icon = 0x7F08009E;  // id:right_icon
        public static final int right_side = 0x7F08009F;  // id:right_side
        public static final int tag_transition_group = 0x7F0800CA;  // id:tag_transition_group
        public static final int tag_unhandled_key_event_manager = 0x7F0800CB;  // id:tag_unhandled_key_event_manager
        public static final int tag_unhandled_key_listeners = 0x7F0800CC;  // id:tag_unhandled_key_listeners
        public static final int text = 0x7F0800CE;  // id:text
        public static final int text2 = 0x7F0800CF;  // id:text2
        public static final int time = 0x7F0800D4;  // id:time
        public static final int title = 0x7F0800D6;  // id:title

    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 0x7F090005;  // integer:status_bar_notification_info_maxnum

    }

    public static final class layout {
        public static final int notification_action = 0x7F0B0020;  // layout:notification_action
        public static final int notification_action_tombstone = 0x7F0B0021;  // layout:notification_action_tombstone
        public static final int notification_template_custom_big = 0x7F0B0028;  // layout:notification_template_custom_big
        public static final int notification_template_icon_group = 0x7F0B0029;  // layout:notification_template_icon_group
        public static final int notification_template_part_chronometer = 0x7F0B002D;  // layout:notification_template_part_chronometer
        public static final int notification_template_part_time = 0x7F0B002E;  // layout:notification_template_part_time

    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 0x7F0E007C;  // string:status_bar_notification_info_overflow "999+"

    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 0x7F0F00F6;  // style:TextAppearance.Compat.Notification
        public static final int TextAppearance_Compat_Notification_Info = 0x7F0F00F7;  // style:TextAppearance.Compat.Notification.Info
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7F0F00F9;  // style:TextAppearance.Compat.Notification.Line2
        public static final int TextAppearance_Compat_Notification_Time = 0x7F0F00FC;  // style:TextAppearance.Compat.Notification.Time
        public static final int TextAppearance_Compat_Notification_Title = 0x7F0F00FE;  // style:TextAppearance.Compat.Notification.Title
        public static final int Widget_Compat_NotificationActionContainer = 0x7F0F0170;  // style:Widget.Compat.NotificationActionContainer
        public static final int Widget_Compat_NotificationActionText = 0x7F0F0171;  // style:Widget.Compat.NotificationActionText

    }

    public static final class styleable {
        public static final int[] ColorStateListItem = null;
        public static final int ColorStateListItem_alpha = 3;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int ColorStateListItem_android_lStar = 2;
        public static final int ColorStateListItem_lStar = 4;
        public static final int[] FontFamily = null;
        public static final int[] FontFamilyFont = null;
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int FontFamily_fontProviderSystemFontFamily = 6;
        public static final int[] GradientColor = null;
        public static final int[] GradientColorItem = null;
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;

        static {
            styleable.ColorStateListItem = new int[]{0x10101A5, 0x101031F, 0x1010647, 0x7F030029, 0x7F0300AB};  // attr:alpha
            styleable.FontFamily = new int[]{0x7F03008F, 0x7F030090, 0x7F030091, 0x7F030092, 0x7F030093, 0x7F030094, 0x7F030095};  // attr:fontProviderAuthority
            styleable.FontFamilyFont = new int[]{0x1010532, 0x1010533, 0x101053F, 0x101056F, 0x1010570, 0x7F03008D, 0x7F030096, 0x7F030097, 0x7F030098, 0x7F03012B};  // attr:font
            styleable.GradientColor = new int[]{0x101019D, 0x101019E, 0x10101A1, 0x10101A2, 0x10101A3, 0x10101A4, 0x1010201, 0x101020B, 0x1010510, 0x1010511, 0x1010512, 0x1010513};
            styleable.GradientColorItem = new int[]{0x10101A5, 0x1010514};
        }
    }

}

