package androidx.activity;

import android.content.Context;
import androidx.activity.contextaware.OnContextAvailableListener;

public final class ComponentActivity..ExternalSyntheticLambda2 implements OnContextAvailableListener {
    public final ComponentActivity f$0;

    public ComponentActivity..ExternalSyntheticLambda2(ComponentActivity componentActivity0) {
        this.f$0 = componentActivity0;
    }

    @Override  // androidx.activity.contextaware.OnContextAvailableListener
    public final void onContextAvailable(Context context0) {
        this.f$0.lambda$new$1$androidx-activity-ComponentActivity(context0);
    }
}

