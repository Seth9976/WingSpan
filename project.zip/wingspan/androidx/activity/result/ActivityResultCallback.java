package androidx.activity.result;

public interface ActivityResultCallback {
    void onActivityResult(Object arg1);
}

