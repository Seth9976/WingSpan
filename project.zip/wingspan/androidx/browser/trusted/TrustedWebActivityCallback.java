package androidx.browser.trusted;

import android.os.Bundle;

public abstract class TrustedWebActivityCallback {
    public abstract void onExtraCallback(String arg1, Bundle arg2);
}

