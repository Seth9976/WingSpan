package androidx.browser.trusted;

import java.util.Comparator;

public final class TokenContents..ExternalSyntheticLambda0 implements Comparator {
    @Override
    public final int compare(Object object0, Object object1) {
        return TokenContents.compareByteArrays(((byte[])object0), ((byte[])object1));
    }
}

