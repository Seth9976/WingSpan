package androidx.core.content.res;

public final class ResourcesCompat.FontCallback..ExternalSyntheticLambda1 implements Runnable {
    public final FontCallback f$0;
    public final int f$1;

    public ResourcesCompat.FontCallback..ExternalSyntheticLambda1(FontCallback resourcesCompat$FontCallback0, int v) {
        this.f$0 = resourcesCompat$FontCallback0;
        this.f$1 = v;
    }

    @Override
    public final void run() {
        this.f$0.lambda$callbackFailAsync$1$androidx-core-content-res-ResourcesCompat$FontCallback(this.f$1);
    }
}

