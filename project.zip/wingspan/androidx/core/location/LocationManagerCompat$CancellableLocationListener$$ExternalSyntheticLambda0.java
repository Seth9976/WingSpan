package androidx.core.location;

public final class LocationManagerCompat.CancellableLocationListener..ExternalSyntheticLambda0 implements Runnable {
    public final CancellableLocationListener f$0;

    public LocationManagerCompat.CancellableLocationListener..ExternalSyntheticLambda0(CancellableLocationListener locationManagerCompat$CancellableLocationListener0) {
        this.f$0 = locationManagerCompat$CancellableLocationListener0;
    }

    @Override
    public final void run() {
        this.f$0.lambda$startTimeout$0$androidx-core-location-LocationManagerCompat$CancellableLocationListener();
    }
}

