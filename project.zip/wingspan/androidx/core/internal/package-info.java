package androidx.core.internal;

interface package-info {
}

