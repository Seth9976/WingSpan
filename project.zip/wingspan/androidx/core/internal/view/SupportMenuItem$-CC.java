package androidx.core.internal.view;

import android.view.MenuItem;

public final class SupportMenuItem.-CC {
    public static MenuItem $default$setContentDescription(SupportMenuItem _this, CharSequence charSequence0) {
        return _this.setContentDescription(charSequence0);
    }

    public static MenuItem $default$setTooltipText(SupportMenuItem _this, CharSequence charSequence0) {
        return _this.setTooltipText(charSequence0);
    }
}

