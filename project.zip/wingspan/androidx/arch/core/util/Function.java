package androidx.arch.core.util;

public interface Function {
    Object apply(Object arg1);
}

